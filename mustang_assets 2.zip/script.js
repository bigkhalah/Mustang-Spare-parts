// Mustang Spare Parts - Script
document.addEventListener("DOMContentLoaded", () => {
    console.log("Mustang Assets Loaded");
});
