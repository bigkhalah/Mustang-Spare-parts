# Mustang Spare Parts

A simple website showcasing Mustang spare parts with worldwide shipping from California, USA.

## Features
- Responsive design
- Hero banner
- Product showcase section
- Instagram QR code
- Contact information

## File Structure
- `index.html` → Main HTML file
- `style.css` → Styling
- `logo.png` → Placeholder logo
- `mustang-bg.jpg` → Background image
- `instagram-qr.png` → Instagram QR placeholder
- `products/` → Folder containing product images

## How to Use
1. Upload all files to your GitHub repository.
2. Enable **GitHub Pages** in repository settings.
3. Your site will be live at: `https://<username>.github.io/<repository-name>/`
