function buyNow() {
    alert("Thank you for your interest! This feature will be available soon.");
}
