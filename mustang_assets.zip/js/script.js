document.addEventListener("DOMContentLoaded", function() {
    alert("Mustang Assets Loaded Successfully!");
});
