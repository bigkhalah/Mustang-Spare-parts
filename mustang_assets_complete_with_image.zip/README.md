# Mustang Spare Parts

This is a sample website project for Mustang spare parts.

## Project Structure

- `index.html` - Main page
- `assets/css/style.css` - Stylesheet
- `assets/js/script.js` - JavaScript file
- `assets/images/sample_part.png` - Sample image

## How to Run

1. Clone the repository or download the files.
2. Open `index.html` in your browser.
