document.addEventListener("DOMContentLoaded", () => {
  console.log("Mustang Spare Parts site loaded!");
});