# Mustang Spare Parts

This repository contains a simple static website for showcasing Mustang spare parts.

## Structure
- `index.html` – Main landing page  
- `styles.css` – Styling for the site  
- `assets/images/sample.jpg` – Sample image placeholder  
- `.github/workflows/unpack.yml` – GitHub Actions workflow for building/deploying

## Deployment
This project is set up to be deployed with **GitHub Pages** automatically.

1. Push this repo to GitHub.  
2. Ensure GitHub Pages is enabled in repo settings (`Settings > Pages`).  
3. On each push to `main`, the workflow will deploy to GitHub Pages.

Enjoy 🚗💨
