# Mustang Parts Website

This is a sample Mustang Parts website hosted on GitHub Pages.

## Features
- Home, About, Parts, and Contact pages
- SEO-friendly `robots.txt` and `sitemap.xml`
- Google Search Console verification file included
- Simple responsive design

## Deployment
1. Upload all files to your GitHub repo.
2. Enable GitHub Pages in your repo settings.
3. Submit `sitemap.xml` to Google Search Console.
